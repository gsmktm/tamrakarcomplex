# Data Architecture Issues Analysis
## May 10, 2026

---

## Issue #1: Exchange Form Routing ✅ VERIFIED CORRECT

**Status**: Currently works correctly
- `ExchangeYourPhone.tsx` submits to `submitExchangeRequest()` in submissionService.ts
- Saves to **single canonical table**: `exchange_requests` with nullable `store_id`
  - `store_id = null` → Official/platform exchange
  - `store_id = <uuid>` → Store-specific exchange
- `ExchangeManager.tsx` correctly filters by `store_id`
- Comment notes: "store_exchange_requests is deprecated"

**Recommendation**: No change needed. Keep using exchange_requests table exclusively.

---

## Issue #2: Store Products Schema Mismatch ⚠️ CRITICAL

**Problem**: Three separate inventory tables with diverging usage patterns

### Three Table Situation:

#### 1. `store_products` (PRIMARY IN USE)
- **Location**: supabase/migrations/20260507050000_store_os_final.sql
- **Current State**: Active, used by inventoryService.ts
- **Columns**: id, store_id, product_type, brand_id, model_id, title, slug, condition, storage, color, price, discount_price, stock_quantity, images, status
- **Latest Additions** (20260510010000):
  - `catalog_product_id` (link to official catalog)
  - `created_by`, `description`, `stock`, `price_sale`, `price_mrp`
- **Usage Pattern**: 
  - Read: inventoryService.getStoreInventory()
  - Write: inventoryService.addToInventory(), updateInventoryItem()
  - Query: marketplace listings, storefront products
- **RLS Policy**: "Staff can manage products" (store admins via can_manage_store())

#### 2. `store_inventory` (SECONDARY, UNDERUTILIZED)
- **Location**: supabase/migrations/20260425010000_device_catalog_and_inventory.sql
- **Current State**: Defined in migrations but NOT actively used in TypeScript services
- **Columns**: id, store_id, catalog_product_id (FK), condition, stock_qty, price, warranty, status, source_type, last_updated_by
- **Design**: Designed as linking table between stores and official catalog_products
- **RLS Policy**: "Store admins can manage their own inventory"
- **Problem**: Code doesn't use this table; inventoryService uses store_products instead
- **Trigger Attempt** (20260506020000): Tries to UPDATE store_inventory on order (BUT code doesn't populate it)

#### 3. `inventory_items` (LEGACY MASTER DATA)
- **Location**: supabase/migrations/20260505000000_master_mobile_database.sql
- **Current State**: Master data table for mobile specifications
- **Columns**: id, model_id, variant_id, store_id, price, stock_quantity, condition, warranty, status
- **Usage**: mobileMasterService.ts uses this for master data operations
- **Design Purpose**: Not for store inventory, but master product specifications
- **RLS Policy**: "Allow public read access"
- **Trigger Attempt** (20260506020000): Tries to UPDATE inventory_items on order (BUT data isn't there)

### The Problem in Detail:

```sql
-- STORE_PRODUCTS (Real usage, actively managed)
INSERT/UPDATE: store_products (store-specific listings)
READ: inventoryService.getStoreInventory() ← USED
      marketplace queries use store_products ← USED

-- STORE_INVENTORY (Dead code)
INSERT/UPDATE: Never happens in TypeScript
READ: Never happens in TypeScript
      Only exists in schema
      Trigger tries to update it (pointless)

-- INVENTORY_ITEMS (Wrong purpose)
INSERT/UPDATE: mobileMasterService uses it for master data
READ: Never queried in marketplace/store contexts
      Only for admin master data management
```

### Flow Divergence:

**When order is placed:**
```
order creation
  ↓
trigger: 20260506020000_full_stack_logic_triggers.sql line 43
  ↓
UPDATE inventory_items SET stock = stock - qty  ← WRONG TABLE
UPDATE store_inventory SET stock_qty = ...      ← WRONG TABLE
  ↓
But actual store inventory is in: store_products (stock_quantity field)
  ↓
RESULT: Real inventory never decremented! BROKEN
```

---

## Issue #3: Price List Locking ✅ MOSTLY CORRECT

**Status**: Official prices are correctly locked to catalog_products

### Price Architecture:

#### Official Prices (LOCKED):
- **Table**: `catalog_products`
- **Columns**: `official_price`, `market_price`, `is_price_list_item`, `verified`
- **Service**: `priceListService.ts`
- **Write Access**: Platform staff only (suadmin/staffadmin)
- **RLS Policy**: "Platform staff manage official price list" - checks `user_roles.role IN ('suadmin', 'staffadmin', 'admin')`
- **Disabled Function**: `syncFromOldProducts()` throws error: "Legacy products sync is disabled. Manage official prices in catalog_products."

#### Store Prices (CHANGEABLE):
- **Table**: `store_products`
- **Columns**: `price`, `discount_price`, `price_sale`, `price_mrp`
- **Service**: `inventoryService.ts`
- **Write Access**: Store admins via store-specific queries
- **Purpose**: Store can set own margins over official price
- **Allowed**: Different from official price ✅

#### Master Data Prices:
- **Table**: `inventory_items` (legacy)
- **Column**: `price`
- **Usage**: mobileMasterService for master data management

### Current State: ✅ SECURE
- Official prices cannot be changed by store admins (RLS prevents)
- Store prices can differ from official prices (by design)
- priceListService correctly disables legacy syncs
- No way to bypass official price protection

### Recommendation: No critical changes needed
- Could clean up unused price columns in store_products for clarity
- Consider deprecating inventory_items.price in favor of catalog_products

---

## Issue #4: Store Application Approval Workflow ✅ ALREADY FIXED

**Status**: Already corrected in previous work

**What was fixed:**
- Store no longer auto-publishes when application is created
- `completeFullStackStoreOnboarding()` creates with `status: "pending_approval"` instead of "active"
- `public_status: "draft"` (not "published")
- New explicit `publishStore()` function required admin approval
- StoreApplicationManager shows Publish button only after approval

**Current Flow:**
```
1. User applies → Store created (status: pending_approval, public_status: draft)
2. Admin reviews → Application status changes
3. Admin clicks "Publish" → publishStore() called
4. Store becomes (status: active, public_status: published)
```

---

## Issue #5: Dead/Unwanted Files Cleanup

### Files That Can Be Removed:

#### 1. Deprecated Migration Files:
- `supabase/migrations/20260505000000_master_mobile_database.sql`
  - Reason: Creates inventory_items, phone_models, phone_variants (not used in modern code)
  - Impact: Low (schema already exists, can stay for reference)
  - Action: Mark as deprecated with comment

#### 2. Unused Service:
- `src/services/mobileMasterService.ts`
  - Reason: Only used for master data maintenance (phone_models, phone_variants)
  - References: Uses inventory_items table (deprecated)
  - Impact: Low (used only in admin contexts for master data)
  - Action: Keep but mark as legacy

#### 3. Deprecated Table References:
- `store_exchange_requests` table
  - Reason: Replaced by exchange_requests table
  - Action: Keep schema for backward compatibility, add deprecation note
  - Timeline: Can remove in 2-3 quarters

#### 4. Fallback/Legacy Code Branches:
- Various "legacy" fallback payloads in submissionService.ts, repairService.ts
- Purpose: Handle schema evolution gracefully
- Status: Safe to keep (provides resilience)
- Action: Document why they're needed

### Files That Should Be Kept:

- `evostoreService.ts` line 223 comment mentions "deprecated"
  - Actually still used by store management
  - Comment outdated, just needs update

### Build Artifacts (Already Ignored):
- `replatform/apps/web/.next/` folder
- Build outputs (don't commit)

---

## Recommendations for Final Cleanup

### HIGH PRIORITY (Blocking):
1. Fix inventory deduction on order: Change trigger to use `store_products(stock_quantity)` not inventory_items
2. Update order trigger to track which table contains real inventory

### MEDIUM PRIORITY (Next Sprint):
1. Consolidate store_inventory and store_products into single table
2. Remove store_inventory references from triggers
3. Mark store_exchange_requests as deprecated in schema
4. Update evostoreService.ts comment (no longer deprecated)

### LOW PRIORITY (Long-term):
1. Remove inventory_items references when master data rebuild is complete
2. Deprecate mobileMasterService after master data migration
3. Remove legacy fallback payloads after schema stabilizes (2-3 quarters)

---

## Summary Table

| Item | Status | Action | Timeline |
|------|--------|--------|----------|
| Exchange routing | ✅ Correct | None | - |
| store_products usage | ⚠️ Primary table, underutilized schema | Consolidate | Now |
| store_inventory table | ⚠️ Unused | Remove from active code | Now |
| inventory_items table | ⚠️ Legacy master data | Mark deprecated | 3 months |
| Catalog_products prices | ✅ Secure | None | - |
| Store approval workflow | ✅ Fixed | None | - |
| Order inventory deduction | 🔴 BROKEN | Fix trigger | NOW |

