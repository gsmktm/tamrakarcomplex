# Critical Fixes Deployment Guide
## May 10, 2026

---

## Summary of Critical Issues Found & Fixed

### 1. ✅ Exchange Form Routing
**Status**: CORRECT - No changes needed
- Uses single canonical table: `exchange_requests` with nullable `store_id`
- StoreExchangeRequests table marked as deprecated (kept for compatibility)

### 2. 🔴 CRITICAL: Store Inventory Not Being Deducted on Order
**Status**: BROKEN - FIXED
- **Problem**: Old trigger tried to update `inventory_items` table but real inventory is in `store_products`
- **Impact**: When orders are placed, store inventory stock_quantity never decreases
- **Result**: Stores can oversell inventory indefinitely
- **Fix**: Created new migration `20260510040000_fix_store_inventory_deduction.sql`
- **What it does**:
  - Adds trigger on order_items INSERT to deduct from store_products.stock_quantity
  - Adds trigger on order_items DELETE to restore stock if order is cancelled
  - Uses store_id and catalog_product_id matching for accuracy

### 3. ✅ Official Price List Locking
**Status**: CORRECT - No changes needed
- Official prices only in `catalog_products` table
- RLS policy prevents store admins from modifying
- Store prices in `store_products` are separate (allowed to differ)
- Legacy sync disabled with error message

### 4. ✅ Store Application Auto-Publication
**Status**: FIXED (previous work)
- Stores no longer auto-publish when application created
- Must be explicitly approved and published by admin
- Two-step workflow: approve → publish

### 5. ⚠️ Schema Consolidation Needed
**Status**: PENDING
- Three inventory tables exist: `store_products`, `store_inventory`, `inventory_items`
- `store_inventory` is unused in TypeScript code
- `inventory_items` is legacy master data table
- Recommendation: Use only `store_products` as source of truth

---

## Deployment Checklist

### IMMEDIATE (Before Production):

#### 1. Deploy RLS Policy Fix
- **File**: `supabase/migrations/20260510030000_fix_orders_rls_policy_store_admins.sql`
- **Status**: Ready
- **Action**: Deploy to Supabase
- **Test**: 
  ```sql
  -- Test that storeadmin (not owner) can see orders
  SELECT COUNT(*) FROM orders 
  WHERE EXISTS (
    SELECT 1 FROM order_items oi
    JOIN stores s ON s.id = oi.store_id
    WHERE oi.order_id = orders.id
    AND (
      s.owner_id = <test_user_id>
      OR EXISTS (
        SELECT 1 FROM store_admins sa
        WHERE sa.store_id = s.id
        AND sa.user_id = <test_user_id>
        AND sa.status = 'active'
      )
    )
  );
  ```

#### 2. Deploy Package Sync Trigger
- **File**: `supabase/migrations/20260510020000_sync_package_slug_trigger.sql`
- **Status**: Ready
- **Action**: Deploy to Supabase
- **Test**:
  ```sql
  -- Verify trigger exists
  SELECT tgname FROM pg_trigger WHERE tgname = 'trg_sync_package_slug';
  
  -- Test sync: Change package_id and verify package_slug updates
  UPDATE stores SET package_id = <new_package_id> WHERE id = <test_store_id>;
  SELECT package_id, package_slug FROM stores WHERE id = <test_store_id>;
  ```

#### 3. Deploy Inventory Deduction Fix
- **File**: `supabase/migrations/20260510040000_fix_store_inventory_deduction.sql`
- **Status**: Ready
- **Action**: Deploy to Supabase
- **Test**:
  ```sql
  -- Check triggers exist
  SELECT tgname FROM pg_trigger WHERE tgname LIKE 'trg_%store_inventory%';
  
  -- Test deduction: Create order item and verify stock decreases
  SELECT stock_quantity FROM store_products 
  WHERE id = <test_product_id> 
  AND store_id = <test_store_id>;
  -- Insert order item
  INSERT INTO order_items(order_id, product_id, store_id, quantity) 
  VALUES(<order_id>, <test_product_id>, <test_store_id>, 1);
  -- Verify stock decreased by 1
  SELECT stock_quantity FROM store_products 
  WHERE id = <test_product_id> 
  AND store_id = <test_store_id>;
  ```

---

## Build & Validation

### Pre-Deployment Tests

```bash
# 1. Build confirms all changes
npm run build

# 2. TypeScript compilation passes
npx tsc --noEmit

# 3. Lint passes
npm run lint
```

### Database Validation

```sql
-- 1. Verify migration files exist
\dt public.* | grep -E 'store_products|store_inventory|exchange_requests'

-- 2. Check RLS policies
SELECT schemaname, tablename, policyname FROM pg_policies 
WHERE tablename IN ('orders', 'store_payouts', 'store_commissions');

-- 3. Verify triggers
SELECT tgname, tgrelname FROM pg_trigger 
WHERE tgname LIKE 'trg_%' 
ORDER BY tgrelname;

-- 4. Test inventory deduction
-- Create test order with item
-- Verify store_products.stock_quantity decreases
```

---

## Post-Deployment Monitoring

### Key Metrics to Monitor:

1. **Order Processing**
   - Check if orders are being created successfully
   - Verify inventory tracking in store_products table

2. **Store Admin Access**
   - Verify store admins can see their orders
   - Verify store admins cannot see other stores' orders

3. **Package Sync**
   - Monitor for package_id/package_slug divergence
   - Check if trigger fires on package changes

---

## Schema Cleanup (Next Sprint)

### Recommended Changes:

1. **Consolidate inventory**
   ```sql
   -- Mark store_inventory as deprecated
   ALTER TABLE public.store_inventory RENAME TO public.store_inventory_deprecated;
   
   -- All inventory now tracked in store_products
   -- Future: Remove store_inventory_deprecated after 3 month grace period
   ```

2. **Archive old triggers**
   ```sql
   -- Mark old trigger as deprecated
   DROP TRIGGER IF EXISTS trg_deduct_stock_on_order ON public.order_items;
   DROP FUNCTION IF EXISTS public.deduct_stock_on_order();
   ```

3. **Document data flow**
   - Update ARCHITECTURE.md
   - Document inventory table as source of truth: store_products
   - Link package entitlements to package_id (not package_slug)

---

## Files Modified/Created

| File | Status | Type | Action |
|------|--------|------|--------|
| supabase/migrations/20260510020000_sync_package_slug_trigger.sql | New | Migration | Deploy |
| supabase/migrations/20260510030000_fix_orders_rls_policy_store_admins.sql | New | Migration | Deploy |
| supabase/migrations/20260510040000_fix_store_inventory_deduction.sql | New | Migration | Deploy |
| src/lib/packageConsistency.ts | New | Utility | Use in features |
| src/pages/admin/OrderManager.tsx | Modified | Component | Deployed |
| src/pages/admin/PayoutManager.tsx | Modified | Component | Deployed |
| src/pages/admin/StoreApplicationManager.tsx | Modified | Component | Deployed |
| src/services/submissionService.ts | Modified | Service | Deployed |
| src/services/storeDirectoryService.ts | Modified | Service | Deployed |
| src/services/repairService.ts | Modified | Service | Deployed |
| SECURITY_VALIDATION_REPORT_20260510.md | New | Report | Reference |
| DATA_ARCHITECTURE_ISSUES.md | New | Report | Reference |

---

## Rollback Plan

If any migration causes issues:

```sql
-- Rollback inventory triggers
DROP TRIGGER IF EXISTS trg_deduct_store_inventory_on_order ON public.order_items;
DROP TRIGGER IF EXISTS trg_restore_store_inventory_on_delete ON public.order_items;
DROP FUNCTION IF EXISTS public.deduct_store_inventory_on_order();
DROP FUNCTION IF EXISTS public.restore_store_inventory_on_order_cancel();

-- Rollback RLS policy
DROP POLICY IF EXISTS "Store admins can view own store orders" ON public.orders;
DROP POLICY IF EXISTS "Store admins can view own order items" ON public.order_items;
-- Then recreate old policy if needed

-- Rollback package trigger
DROP TRIGGER IF EXISTS trg_sync_package_slug ON public.stores;
DROP FUNCTION IF EXISTS public.sync_package_slug_on_update();
```

---

## Sign-Off Checklist

- [ ] All migrations reviewed and syntax verified
- [ ] RLS policies tested with store admin accounts
- [ ] Inventory deduction trigger tested with test orders
- [ ] Build passes with all changes
- [ ] No TypeScript errors
- [ ] Existing order processing tested
- [ ] Store application workflow tested
- [ ] Price list locking confirmed
- [ ] Package sync trigger confirmed firing

**Once all checked**: Ready for production deployment

